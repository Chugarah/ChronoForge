(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/components_contact_MapIframe_tsx_4dfcad._.js", {

"[project]/components/contact/MapIframe.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>MapIframe)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$6_$40$babel$2b$core$40$7$2e$26$2e$9_$40$opentelemetry$2b$api$40$1$2e$7$2e$0_$40$playwright$2b$test$40$1$2e$50$2e$1_babel$2d$plugin$2d$_jrwq3sailumijw65kmdwrt4ei4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/.pnpm/next@15.1.6_@babel+core@7.26.9_@opentelemetry+api@1.7.0_@playwright+test@1.50.1_babel-plugin-_jrwq3sailumijw65kmdwrt4ei4/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function MapIframe() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$15$2e$1$2e$6_$40$babel$2b$core$40$7$2e$26$2e$9_$40$opentelemetry$2b$api$40$1$2e$7$2e$0_$40$playwright$2b$test$40$1$2e$50$2e$1_babel$2d$plugin$2d$_jrwq3sailumijw65kmdwrt4ei4$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("iframe", {
        src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.7270791764607!2d-122.42375678441455!3d37.77559797975886!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8085809c6c8f4459%3A0xb10ed6d9b5050fa5!2sTwitter+HQ!5e0!3m2!1sen!2s!4v1523304626667",
        width: "100%",
        height: "540",
        className: "rounded-lg shadow-lg border-0",
        allowFullScreen: true,
        referrerPolicy: "no-referrer-when-downgrade",
        title: "Google Maps"
    }, void 0, false, {
        fileName: "[project]/components/contact/MapIframe.tsx",
        lineNumber: 3,
        columnNumber: 5
    }, this);
}
_c = MapIframe;
var _c;
__turbopack_refresh__.register(_c, "MapIframe");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=components_contact_MapIframe_tsx_4dfcad._.js.map