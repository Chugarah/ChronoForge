(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(ROOT)_project_page_tsx_a443a6._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(ROOT)_project_page_tsx_a443a6._.js",
  "chunks": [
    "static/chunks/_010b1c._.js",
    "static/chunks/components_contact_MapIframe_tsx_696743._.js"
  ],
  "source": "dynamic"
});
