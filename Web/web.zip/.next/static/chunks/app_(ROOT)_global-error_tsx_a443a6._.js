(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_(ROOT)_global-error_tsx_a443a6._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_(ROOT)_global-error_tsx_a443a6._.js",
  "chunks": [
    "static/chunks/_6d12f3._.js"
  ],
  "source": "dynamic"
});
