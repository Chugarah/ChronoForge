(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_error_tsx_875dd6._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_error_tsx_875dd6._.js",
  "chunks": [
    "static/chunks/_e9e691._.js"
  ],
  "source": "dynamic"
});
