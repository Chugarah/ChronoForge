(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/_e69f0d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/_e69f0d._.js",
  "chunks": [
    "static/chunks/38059_next_dist_compiled_react-dom_07c1a4._.js",
    "static/chunks/38059_next_dist_compiled_3d0907._.js",
    "static/chunks/38059_next_dist_client_e16b4b._.js",
    "static/chunks/38059_next_dist_1b0d77._.js",
    "static/chunks/61dca_@swc_helpers_cjs_e27e0a._.js",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_833fcb._.js"
  ],
  "source": "entry"
});
