(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_7db0df._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_7db0df._.js",
  "chunks": [
    "static/chunks/styles_tailwind_a431ab.css",
    "static/chunks/_be3ef0._.js"
  ],
  "source": "dynamic"
});
