(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_4a8a00._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_4a8a00._.js",
  "chunks": [
    "static/chunks/styles_tailwind_a431ab.css",
    "static/chunks/_1baff3._.js"
  ],
  "source": "dynamic"
});
