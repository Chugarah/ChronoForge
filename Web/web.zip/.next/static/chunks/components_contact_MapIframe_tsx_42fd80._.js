(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/components_contact_MapIframe_tsx_42fd80._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/components_contact_MapIframe_tsx_42fd80._.js",
  "chunks": [
    "static/chunks/components_contact_MapIframe_tsx_4dfcad._.js"
  ],
  "source": "dynamic"
});
