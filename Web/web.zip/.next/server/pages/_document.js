const CHUNK_PUBLIC_PATH = "server/pages/_document.js";
const runtime = require("../chunks/ssr/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/ssr/node_modules__pnpm_553e35._.js");
runtime.loadChunk("server/chunks/ssr/[root of the server]__03c53a._.js");
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/.pnpm/next@15.1.6_@babel+core@7.26.9_@opentelemetry+api@1.7.0_@playwright+test@1.50.1_babel-plugin-_jrwq3sailumijw65kmdwrt4ei4/node_modules/next/document.js [ssr] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
