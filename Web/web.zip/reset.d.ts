import "@total-typescript/ts-reset"
import "typed-query-selector/strict"
